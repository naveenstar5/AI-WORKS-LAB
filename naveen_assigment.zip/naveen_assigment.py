from collections import deque

def adj_list(v, adj):
    for i in range(v):
        print(f"{i} -->", end=" ")
        for l in adj[i]:
            print(l, end=" ")
        print()

def adj_matrix(v, adj):
    a_m = [[0 for _ in range(v)] for _ in range(v)]
    for i in range(v):
        for l in adj[i]:
            a_m[i][l] = 1
    for i in range(v):
        for j in range(v):
            print(a_m[i][j], end=" ")
        print()

def bfs(v, adj):
    vis = [False] * v
    q = deque()
    q.append(0)
    vis[0] = True
    while q:
        node = q.popleft()
        print(node, end=" ")
        for neighbor in adj[node]:
            if not vis[neighbor]:
                vis[neighbor] = True
                q.append(neighbor)

def dfs(node, vis, adj):
    print(node, end=" ")
    vis[node] = True
    for neighbor in adj[node]:
        if not vis[neighbor]:
            dfs(neighbor, vis, adj)

def dfs_wrapper(v, adj):
    vis = [False] * v
    dfs(0, vis, adj)
v = int(input("Enter number of nodes: "))
e = int(input("Enter number of edges: "))
adj = [[] for _ in range(100)]

for _ in range(e):
     a, b = map(int, input().split())
     adj[a].append(b)
     adj[b].append(a)

choice = int(input("Enter your choice:\n1. Adjacency list\n2. Adjacency matrix\n3. BFS\n4. DFS\n5. Exit\n"))

if choice == 1:
     adj_list(v, adj)
elif choice == 2:
    adj_matrix(v, adj)
elif choice == 3:
    bfs(v, adj)
elif choice == 4:
     dfs_wrapper(v, adj)
elif choice == 5:
    exit(0)